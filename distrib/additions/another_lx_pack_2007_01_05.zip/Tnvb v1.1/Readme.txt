======================================================================
                      New Year's Mod for LieroX
                             1 Feb 2005

Official Site: http://forums.thegaminguniverse.com/showthread.php?t=19385
======================================================================

-------
INSTALL
-------

1: Unzip the Tnvb -folder to your LieroX directory.
2: Open LieroX, select Fireworks Mod and press Start.

-----
NOTES
-----

� Current is current version (Fireworks v1.1) not beta (Fireworks v1.0�).
� 0 % loading time is useless, same damage will come on 10% or higher.
� Everybody bow when Tuplanolla or other who was making this appears to join to your current server.
� Some name in (brackets) means that he has edited the original alot or added stuff.
� Number in weapon name will tell the making order.

-------
WEAPONS
-------

(18th) HocusPocus - Confetti Gun
(23rd) HocusPocus & Tuplanolla - Confetti Bomb
(21st) Killjoy - Bee
(22nd) Killjoy - Buzzy Bee Bomb
(20th) Mauganra99 & (Tuplanolla) - Roman Candle
(13th) NobodyX - Remote Rocket Launcher
(26th) NobodyX & Tuplanolla - Firework Strike
(24th) Olin - Volcano
(11th) Olin - Whirlstream
(10th) TTFTCUTS - Display Box
(12th) TTFTCUTS & Tuplanolla - Hand Cracker
(1st)  Tuplanolla - Bazooka
(16th) Tuplanolla - Blue Carnival of Time Fireworks
(5th)  Tuplanolla - Blue Rocket
(3rd)  Tuplanolla - Color Smoke Grenade
(27th) Tuplanolla - Catherine's Wheel
(19th) Tuplanolla - Flare Spray
(9th)  Tuplanolla - Giant Missile Launcher
(6th)  Tuplanolla - Green Rocket
(15th) Tuplanolla - Green Carnival of Time Fireworks
(25th) Tuplanolla - Micro Bombs
(8th)  Tuplanolla - Multicolor Rocket
(14th) Tuplanolla - Purple Carnival of Time Fireworks
(4th)  Tuplanolla - Red Rocket
(28th) Tuplanolla - Sparkinator 3200
(2nd)  Tuplanolla - Sparkler
(7th)  Tuplanolla - White Rocket
(17th) Tuplanolla - Yellow Carnival of Time Fireworks


-------
HISTORY
-------

Version 1.0:
� First version was published 01.02.05.

Version 1.1:
� First version was published 08.05.05.
� Sparkinator 3200 added.
� Weapons rearranged by alphabetical order.
� Very tiny bugs fixed.
� Fixed undefined images.
� Fixes deleted, Tuplanolla done something wrong.
� Mod refixed.
� Weapons balanced, damages adjusted.

-------
MADE BY
-------

Assebly:
Tuplanolla/Sampsa

Sounds:
Mauganra99 - romanshoot.wav
Nige111 - missileblow.wav
Nige111 - missileblowb.wav
(Nige111) & Tuplanolla - bazookablow.wav
NobodyX - remoteblow.wav
The Legend of Zelda - Majoras Mask - zeldablow.wav
Tonttu - wheel.wav
TTFTCUTS - cracker.wav
TTFTCUTS - rocket.wav
Tuplanolla - bazookashoot.wav
Tuplanolla - bee.wav
Tuplanolla - beetoss.wav
Tuplanolla - candle.wav
Tuplanolla - candleblow.wav
Tuplanolla - confetti.wav
Tuplanolla - confettib.wav
Tuplanolla - crackerblow.wav
Tuplanolla - flarespray.wav
Tuplanolla - giantlaunch.wav
Tuplanolla - giantblow.wav
Tuplanolla - microblow.wav
Tuplanolla - missilelaunch.wav
Tuplanolla - rocketblow.wav
Tuplanolla - smoke.wav
Tuplanolla - sparkinator.wav
Tuplanolla - sparkler.wav
Tuplanolla - strike.wav
Tuplanolla - strikeblow.wav
Tuplanolla - strikeblowb.wav
Tuplanolla - strikedrop.wav
Tuplanolla - strikefly.wav
Tuplanolla - strikestart.wav
Tuplanolla - toss.wav
Tuplanolla - tossb.wav
Tuplanolla - whirlstream.wav

Graphics:
HocusPocus - confettiball.png
HocusPocus - goldconfetti.png
HocusPocus - redconfetti.png
HocusPocus - redconfettib.png
HocusPocus - silverconfetti.png
HocusPocus - whiteconfetti.png
Killjoy - bee.png
Killjoy - beebox.png
Killjoy - beetrail.png
Mauganra99 & Tuplanolla - burntromancandle.png
Mauganra99 & (Tuplanolla) - romancandle.png
NobodyX - blueflickerspark.png
NobodyX - miniblueflickerspark.png
NobodyX - minitealflickerspark.png
NobodyX - smokeball.png
NobodyX - tealflickerspark.png
NobodyX & Tuplanolla - minismokeball.png
NobodyX & Tuplanolla - smokeballb.png
Olin - orangespark.png
Olin - yellowspark.png
Olin & (Tuplanolla) - volcano.png
TTFTCUTS - bigdisplayspark.png
TTFTCUTS - burntrocket.png
TTFTCUTS - displaybox.png
TTFTCUTS - displayboxb.png
TTFTCUTS - displayboxc.png
TTFTCUTS - displaycandle.png
TTFTCUTS - displaycracker.png
TTFTCUTS - displaycrackerexplosion.png
TTFTCUTS - displayflare.png
TTFTCUTS - displayrocket.png
TTFTCUTS - displaysmoke.png
TTFTCUTS - displayspark.png
TTFTCUTS - displaytrail.png
TTFTCUTS - longdisplayspark.png
TTFTCUTS - smalldisplayflare.png
Tuplanolla - bigbluespark.png
Tuplanolla - bigexplosion.png
Tuplanolla - biggreenspark.png
Tuplanolla - bigredspark.png
Tuplanolla - bigwhitespark.png
Tuplanolla - bluemissile.png
Tuplanolla - bluesmoke.png
Tuplanolla - bluespark.png
Tuplanolla - bluezeldaspark.png
Tuplanolla - bluezeldasparkb.png
Tuplanolla - burntstick.png
Tuplanolla - darksmoke.png
Tuplanolla - fallball.png
Tuplanolla - fallballb.png
Tuplanolla - fallspark.png
Tuplanolla - flashexplosion.png
Tuplanolla - flashexplosionb.png
Tuplanolla - giantmissile.png
Tuplanolla - giantmissilesmoke.png
Tuplanolla - giantspark.png
Tuplanolla - giantstat.png
Tuplanolla - giantstatb.png
Tuplanolla - greenmissile.png
Tuplanolla - greensmoke.png
Tuplanolla - greenspark.png
Tuplanolla - greenzeldaspark.png
Tuplanolla - greenzeldasparkb.png
Tuplanolla - invisible.png
Tuplanolla - microgrenade.png
Tuplanolla - minibluespark.png
Tuplanolla - minibluezeldaspark.png
Tuplanolla - minibluezeldasparkb.png
Tuplanolla - minigreenspark.png
Tuplanolla - minigreenzeldaspark.png
Tuplanolla - minigreenzeldasparkb.png
Tuplanolla - minimicrospark.png
Tuplanolla - minipurplezeldaspark.png
Tuplanolla - minipurplezeldasparkb.png
Tuplanolla - miniredspark.png
Tuplanolla - minisprayflare.png
Tuplanolla - miniwhitespark.png
Tuplanolla - miniyellowzeldaspark.png
Tuplanolla - miniyellowzeldasparkb.png
Tuplanolla - missilesmoke.png
Tuplanolla - multimissile.png
Tuplanolla - purplezeldaspark.png
Tuplanolla - purplezeldasparkb.png
Tuplanolla - redmissile.png
Tuplanolla - redsmoke.png
Tuplanolla - redspark.png
Tuplanolla - remotedown.png
Tuplanolla - remotelauncher.png
Tuplanolla - remoteup.png
Tuplanolla - rocket.png
Tuplanolla - sprayflare.png
Tuplanolla - squaregrenade.png
Tuplanolla - stick.png
Tuplanolla - strike.png
Tuplanolla - wave.png
Tuplanolla - wheel.png
Tuplanolla - whitesmoke.png
Tuplanolla - whitespark.png
Tuplanolla - yellowsmoke.png
Tuplanolla - yellowzeldaspark.png
Tuplanolla - yellowzeldasparkb.png
Tuplanolla & (Olin) - whitemissile.png