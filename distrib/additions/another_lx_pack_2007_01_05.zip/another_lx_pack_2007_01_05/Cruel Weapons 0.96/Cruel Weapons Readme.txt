Cruel Weapons for Liero Xtreme by TTFTCUTS. V0.96b


Installation:

To install this mod, simply unzip the file into your lieroX directory.

Playing:

To play, select "Cruel v0.96" from the mods menu in local or net play.

Features:

241 weapons in total including many new "cruel" weapons such as the Graviton Impact Cannon, solaris, chainsaw, many types of airstrike and all of your old favourites... many improved to come closer to the new weapons, new graphics and explosions which repel the player. Also now (ver. 0.90 onwards) utility weapons, such as the springboard and elevator!

Explosions (except the star one), health, bonus box, sparkle, spawn and giblet animations are by Strider (many thanks!!)

!!Warning!!: This mod uses a LOT of porjectiles, so use on a computer below about 500mhz is not recommended!

Send any comments to Emperorlexx@hotmail.com or post them at
http://forums.thegaminguniverse.com/showthread.php?s=&threadid=8190

p.s. Many thanks to Jason Boettcher for making the dream of 8 player Liero come alive and fixing that annoying bug that caused level filtering to crash massive levels (I felt 8 player CPU slug-outs were just too cramped on a standard map...), Mog for hosting the mod and the whole GU LieroX community for inspiration, criticism and, more importantly, downloading it!